
import socket 
from threading import Thread 
from socketserver import ThreadingMixIn
import os
import pickle
import shutil
import hmac
import hashlib
import base64
import random
from Homomorphic import decryptData

running = True

def startDistributedCore():
    class CoreThread(Thread): 
 
        def __init__(self,ip,port): 
            Thread.__init__(self) 
            self.ip = ip 
            self.port = port 
            print('Request received from Sender IP : '+ip+' with port no : '+str(port)+"\n") 
 
        def getSignature(self, msg, secret_key):
            blocks = []
            for i in range(len(msg)):
                block = ord(msg[i])
                padded_binary = format(block, '08b')
                blocks.append(padded_binary)
            block = ' '.join(blocks)
            digest = hmac.new(str(secret_key).encode(), msg = block.encode(), digestmod = hashlib.sha512).digest()
            signature = base64.b64encode(digest).decode()
            return signature
        
        def run(self): 
            data = conn.recv(100000)
            response = pickle.loads(data)
            src = response[0]
            secret_key = int(response[1])
            enc = response[2]
            signature = response[3]
            print(src)
            print("Received Encrypted Data : "+str(enc))
            print("Received Signature : "+signature)
            dec = ""
            for i in range(len(enc)):
                dec += chr(decryptData(enc[i]))
            print("Decrypted Data : "+dec+"\n")
            gen_signature = self.getSignature(dec.strip(), secret_key)
            if signature == gen_signature:
                print("Integrity Verification Successful")
                conn.send("Integrity Verification Successful".encode())
            else:
                print("Integrity Verification Failed")
                conn.send("Integrity Verification Failed".encode())
            
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1) 
    server.bind(('localhost', 2222))
    threads = []
    print("Receiver Node Started\n\n")
    while running:
        server.listen(4)
        (conn, (ip,port)) = server.accept()
        newthread = CoreThread(ip,port) 
        newthread.start() 
        threads.append(newthread) 
    for t in threads:
        t.join()

def startCore():
    Thread(target=startDistributedCore).start()


startCore()


