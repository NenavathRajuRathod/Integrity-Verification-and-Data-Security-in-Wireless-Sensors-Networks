python Receiver.py
pause