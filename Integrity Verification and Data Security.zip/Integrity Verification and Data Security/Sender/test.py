import numpy as np
import hmac
import hashlib
import base64
import random
from Homomorphic import encryptData, decryptData

secret_key = random.randint(100,1000)

msg = "hello"
blocks = []
enc = []
for i in range(len(msg)):
    block = ord(msg[i])
    enc.append(encryptData(block))
    padded_binary = format(block, '08b')
    blocks.append(padded_binary)
block = ' '.join(blocks)

digest = hmac.new(str(secret_key).encode(), msg = block.encode(), digestmod = hashlib.sha256).digest()
signature = base64.b64encode(digest).decode()
print(signature)
#print(enc)
for i in range(len(enc)):
    decrypted = chr(decryptData(enc[i]))
    print(decrypted)
