python Sender.py
pause