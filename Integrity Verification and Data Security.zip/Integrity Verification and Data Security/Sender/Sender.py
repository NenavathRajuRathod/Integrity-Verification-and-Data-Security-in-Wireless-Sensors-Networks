import tkinter
from tkinter import *
import math
import random
from threading import Thread 
from collections import defaultdict
from tkinter import ttk
import matplotlib.pyplot as plt
import numpy as np
import time
import random
import numpy as np
import hmac
import hashlib
import base64
import random
from Homomorphic import encryptData
import socket
import pickle

global mobile
global labels
global mobile_x
global mobile_y
global text
global canvas
global source_list, dest_list, tf1
global filename
global p1,p2,p3
global line1,line2,line3
option = 0
global root

def getDistance(iot_x,iot_y,x1,y1):
    flag = False
    for i in range(len(iot_x)):
        dist = math.sqrt((iot_x[i] - x1)**2 + (iot_y[i] - y1)**2)
        if dist < 80:
            flag = True
            break
    return flag

    
def startDataTransferSimulation(text,canvas,line1,line2,x1,y1,x2,y2,x3,y3):
    class SimulationThread(Thread):
        def __init__(self,text,canvas,line1,line2,x1,y1,x2,y2,x3,y3): 
            Thread.__init__(self) 
            self.canvas = canvas
            self.line1 = line1
            self.line2 = line2
            self.x1 = x1
            self.y1 = y1
            self.x2 = x2
            self.y2 = y2
            self.x3 = x3
            self.y3 = y3
            self.text = text
             
        def run(self):
            time.sleep(1)
            for i in range(0,3):
                self.canvas.delete(self.line1)
                self.canvas.delete(self.line2)
                time.sleep(1)
                self.line1 = canvas.create_line(self.x1, self.y1,self.x2, self.y2,fill='black',width=3)
                self.line2 = canvas.create_line(self.x2, self.y2,self.x3, self.y3,fill='black',width=3)
                time.sleep(1)
            self.canvas.delete(self.line1)
            self.canvas.delete(self.line2)
            canvas.update()
                
    newthread = SimulationThread(text,canvas,line1,line2,x1,y1,x2,y2,x3,y3) 
    newthread.start()
    
    
def generateNetwork():
    global mobile
    global labels
    global mobile_x
    global mobile_y
    global source_list, dest_list
    mobile = []
    mobile_x = []
    mobile_y = []
    labels = []
    canvas.update()
    '''
    x = 5
    y = 350
    mobile_x.append(x)
    mobile_y.append(y)
    name = canvas.create_oval(x,y,x+40,y+40, fill="blue")
    lbl = canvas.create_text(x+20,y-10,fill="darkblue",font="Times 7 italic bold",text="BS")
    labels.append(lbl)
    mobile.append(name)
    '''
    for i in range(0,20):
        run = True
        while run == True:
            x = random.randint(100, 450)
            y = random.randint(50, 600)
            flag = getDistance(mobile_x,mobile_y,x,y)
            if flag == False:
                mobile_x.append(x)
                mobile_y.append(y)
                run = False
                name = canvas.create_oval(x,y,x+40,y+40, fill="red")
                lbl = canvas.create_text(x+20,y-10,fill="darkblue",font="Times 8 italic bold",text="Node "+str(i))
                labels.append(lbl)
                mobile.append(name)    

def sendPacket(src, dest, msg):
    from Homomorphic import encryptData #load encryption function from Homomorphic class
    secret_key = random.randint(100,1000)#generate random secret key
    blocks = []
    enc = []
    for i in range(len(msg)): #read each bit from message as block
        block = ord(msg[i]) #convert msg to decimal
        enc.append(encryptData(block)) #encrypt the message using Homomorphic technique
        padded_binary = format(block, '08b') #convert message block into binary and apply padding
        blocks.append(padded_binary)
    block = ' '.join(blocks) #get all blocks from message
    digest = hmac.new(str(secret_key).encode(), msg = block.encode(), digestmod = hashlib.sha512).digest()#convert blocks to hashcode based on secret key and 512 bits
    signature = base64.b64encode(digest).decode() #get signature from message
    text.insert(END,"Packet Sending Details\n")
    text.insert(END,"Plain Text : "+str(msg)+"\n")
    text.insert(END,"Secret Key : "+str(secret_key)+"\n")
    text.insert(END,"Integrity Verification Code : "+str(signature)+"\n")
    text.insert(END,"Encrypted Text : "+str(enc)+"\n\n")
    request = []
    request.append("Source : "+str(src)+" Destination : "+str(dest))
    request.append(str(secret_key))
    request.append(enc)
    request.append(signature)
    request = pickle.dumps(request)
    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
    client.connect(('localhost', 2222))
    client.send(request)
    data = client.recv(100)
    data = data.decode()
    return data

def sendData():
    global option
    global line1,line2,line3
    global source_list, dest_list
    text.delete('1.0', END)
    src = int(source_list.get())
    dest = int(dest_list.get())
    message = tf1.get()
    #src = src + 1
    #dest = dest + 1
    text.insert(END,"Selected Source Node is : "+str(src)+"\n")
    text.insert(END,"Selected Destination Node is : "+str(dest)+"\n")
    if option == 1:
        canvas.delete(line1)
        canvas.delete(line2)
        canvas.update()
    src_x = mobile_x[src]
    src_y = mobile_y[src]
    des_x = mobile_x[dest]
    des_y = mobile_y[dest]
    distance = 10000
    distance1 = 10000
    hop = 0
    for i in range(0,20):
        temp_x = mobile_x[i]
        temp_y = mobile_y[i]
        if i != src and i != dest:
            dist1 = math.sqrt((src_x - temp_x)**2 + (src_y - temp_y)**2)
            dist2 = math.sqrt((des_x - temp_x)**2 + (des_y - temp_y)**2)
            if dist1 < distance and dist2 < distance1:
                distance = dist1
                distance1 = dist2
                hop = i
    if hop != 0:
        hop = hop + 1
        text.insert(END,"Selected Neighbor Node is : "+str(hop)+"\n\n")
        response = sendPacket(src, dest, message)
        line1 = canvas.create_line(mobile_x[src]+20, mobile_y[src]+20,mobile_x[hop]+20, mobile_y[hop]+20,fill='black',width=3)
        line2 = canvas.create_line(mobile_x[hop]+20, mobile_y[hop]+20,mobile_x[dest]+20, mobile_y[dest]+20,fill='black',width=3)
        startDataTransferSimulation(text,canvas,line1,line2,(mobile_x[src]+20),(mobile_y[src]+20),(mobile_x[hop]+20),(mobile_y[hop]+20),(mobile_x[dest]+20),(mobile_y[dest]+20))
        text.insert(END,"Received Response : "+response)
        option = 1
    else:
        text.insert(END,"No shortest path node found. Try another source\n")

def close():
    root.destroy()
    
def Main():
    global root
    global tf1
    global text
    global canvas
    global source_list, dest_list, tf1
    root = tkinter.Tk()
    root.geometry("1300x1200")
    root.title("Integrity Verification & Data Security in Wireless Sensor Networks")
    root.resizable(True,True)
    font1 = ('times', 12, 'bold')

    canvas = Canvas(root, width = 800, height = 700)
    canvas.pack()

    l1 = Label(root, text='Source Node:')
    l1.config(font=font1)
    l1.place(x=820,y=10)

    mid = []
    for i in range(0,20):
        mid.append(str(i))
    source_list = ttk.Combobox(root,values=mid,postcommand=lambda: source_list.configure(values=mid))
    source_list.place(x=970,y=10)
    source_list.current(0)
    source_list.config(font=font1)

    l2 = Label(root, text='Destination Node:')
    l2.config(font=font1)
    l2.place(x=820,y=60)

    mid1 = []
    for i in range(0,20):
        mid1.append(str(i))
    dest_list = ttk.Combobox(root,values=mid1,postcommand=lambda: dest_list.configure(values=mid1))
    dest_list.place(x=970,y=60)
    dest_list.current(0)
    dest_list.config(font=font1)

    l1 = Label(root, text='Secret Message:')
    l1.config(font=font1)
    l1.place(x=820,y=110)

    tf1 = Entry(root,width=40)
    tf1.config(font=font1)
    tf1.place(x=970,y=110)

    createButton = Button(root, text="Generate Network", command=generateNetwork)
    createButton.place(x=820,y=160)
    createButton.config(font=font1)

    initButton = Button(root, text="Send Data", command=sendData)
    initButton.place(x=820,y=210)
    initButton.config(font=font1)

    exitButton = Button(root, text="Exit", command=close)
    exitButton.place(x=820,y=260)
    exitButton.config(font=font1)

    text=Text(root,height=22,width=60)
    scroll=Scrollbar(text)
    text.configure(yscrollcommand=scroll.set)
    text.place(x=820,y=310)
    
    
    root.mainloop()
   
 
if __name__== '__main__' :
    Main ()
    
